package PageObject;

import org.openqa.selenium.WebDriver;

public class basePage {
	public WebDriver driver;
	
	public basePage(WebDriver driver) {
		this.driver= driver;
	
	}

}
